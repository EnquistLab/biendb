# Performs automated queries

Author: Brad Boyle (bboyle@email.arizona.edu)  

### I. Usage

```
./query_db.sh [-<option1> -<option2> ...]
```


* Options:
| Option | Purpose |
| ------ | ------- |
| s      | Silent mode |
| m      | Send start/stop/error ermails |
| a      | Append to existing logfile [replaces file if omitted (default) |
